﻿namespace API_Test
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該公開 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.btnOrder = new System.Windows.Forms.Button();
            this.lstI022 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtRegProductId = new System.Windows.Forms.TextBox();
            this.button28 = new System.Windows.Forms.Button();
            this.txtUserID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtServerIP = new System.Windows.Forms.TextBox();
            this.txtProductID = new System.Windows.Forms.TextBox();
            this.txtBS = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtQTY = new System.Windows.Forms.TextBox();
            this.cmbEffType = new System.Windows.Forms.ComboBox();
            this.cboOpenOffSetFlag = new System.Windows.Forms.ComboBox();
            this.cboML = new System.Windows.Forms.ComboBox();
            this.txtOrderNO = new System.Windows.Forms.TextBox();
            this.grbOrder = new System.Windows.Forms.GroupBox();
            this.btnGetWB = new System.Windows.Forms.Button();
            this.txtProductIdW = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtTime_e = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtTime_s = new System.Windows.Forms.TextBox();
            this.txtOrderNo_e = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtOrderNo_s = new System.Windows.Forms.TextBox();
            this.button12 = new System.Windows.Forms.Button();
            this.cmbActno = new System.Windows.Forms.ComboBox();
            this.button11 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label19 = new System.Windows.Forms.Label();
            this.lstOption = new System.Windows.Forms.ListBox();
            this.label18 = new System.Windows.Forms.Label();
            this.lstFuture = new System.Windows.Forms.ListBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.lstRegItem = new System.Windows.Forms.ListBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lstI080 = new System.Windows.Forms.ListBox();
            this.lstI020 = new System.Windows.Forms.ListBox();
            this.lstI082 = new System.Windows.Forms.ListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnGetWS = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.dgvMatchReply = new System.Windows.Forms.DataGridView();
            this.label13 = new System.Windows.Forms.Label();
            this.dgvOrderReply = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.cmbQueryAccount = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.dgvPosition = new System.Windows.Forms.DataGridView();
            this.button9 = new System.Windows.Forms.Button();
            this.dgvMargin = new System.Windows.Forms.DataGridView();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.txtCompany = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.grbOrder.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatchReply)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderReply)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPosition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMargin)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(568, 15);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(63, 29);
            this.button1.TabIndex = 0;
            this.button1.Text = "Login";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(117, 76);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 29);
            this.button4.TabIndex = 3;
            this.button4.Text = "刪單";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(225, 76);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(100, 29);
            this.button5.TabIndex = 4;
            this.button5.Text = "減量";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(165, 182);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(55, 46);
            this.button7.TabIndex = 6;
            this.button7.Text = "註冊";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(228, 182);
            this.button8.Margin = new System.Windows.Forms.Padding(4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 46);
            this.button8.TabIndex = 7;
            this.button8.Text = "反註冊";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // btnOrder
            // 
            this.btnOrder.Location = new System.Drawing.Point(9, 76);
            this.btnOrder.Margin = new System.Windows.Forms.Padding(4);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(100, 29);
            this.btnOrder.TabIndex = 40;
            this.btnOrder.Text = "下單";
            this.btnOrder.UseVisualStyleBackColor = true;
            this.btnOrder.Click += new System.EventHandler(this.btnOrder_Click);
            // 
            // lstI022
            // 
            this.lstI022.FormattingEnabled = true;
            this.lstI022.ItemHeight = 15;
            this.lstI022.Location = new System.Drawing.Point(25, 340);
            this.lstI022.Margin = new System.Windows.Forms.Padding(4);
            this.lstI022.Name = "lstI022";
            this.lstI022.Size = new System.Drawing.Size(421, 94);
            this.lstI022.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 180);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 13;
            this.label1.Text = "商品名稱";
            // 
            // txtRegProductId
            // 
            this.txtRegProductId.Location = new System.Drawing.Point(29, 199);
            this.txtRegProductId.Margin = new System.Windows.Forms.Padding(4);
            this.txtRegProductId.Name = "txtRegProductId";
            this.txtRegProductId.Size = new System.Drawing.Size(124, 25);
            this.txtRegProductId.TabIndex = 12;
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(333, 76);
            this.button28.Margin = new System.Windows.Forms.Padding(4);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(100, 29);
            this.button28.TabIndex = 24;
            this.button28.Text = "改價";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // txtUserID
            // 
            this.txtUserID.Location = new System.Drawing.Point(399, 15);
            this.txtUserID.Margin = new System.Windows.Forms.Padding(4);
            this.txtUserID.Name = "txtUserID";
            this.txtUserID.Size = new System.Drawing.Size(71, 25);
            this.txtUserID.TabIndex = 27;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(477, 21);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(11, 15);
            this.label2.TabIndex = 28;
            this.label2.Text = "/";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(496, 15);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(4);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(63, 25);
            this.txtPassword.TabIndex = 29;
            this.txtPassword.TextChanged += new System.EventHandler(this.txtPassword_TextChanged);
            // 
            // txtServerIP
            // 
            this.txtServerIP.Location = new System.Drawing.Point(51, 16);
            this.txtServerIP.Margin = new System.Windows.Forms.Padding(4);
            this.txtServerIP.Name = "txtServerIP";
            this.txtServerIP.Size = new System.Drawing.Size(117, 25);
            this.txtServerIP.TabIndex = 30;
            this.txtServerIP.Text = "59.124.59.56";
            this.txtServerIP.UseWaitCursor = true;
            // 
            // txtProductID
            // 
            this.txtProductID.Location = new System.Drawing.Point(221, 41);
            this.txtProductID.Margin = new System.Windows.Forms.Padding(4);
            this.txtProductID.Name = "txtProductID";
            this.txtProductID.Size = new System.Drawing.Size(131, 25);
            this.txtProductID.TabIndex = 32;
            this.txtProductID.Text = "TXFL4";
            // 
            // txtBS
            // 
            this.txtBS.Location = new System.Drawing.Point(361, 41);
            this.txtBS.Margin = new System.Windows.Forms.Padding(4);
            this.txtBS.Name = "txtBS";
            this.txtBS.Size = new System.Drawing.Size(33, 25);
            this.txtBS.TabIndex = 33;
            this.txtBS.Text = "B";
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(416, 41);
            this.txtPrice.Margin = new System.Windows.Forms.Padding(4);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(48, 25);
            this.txtPrice.TabIndex = 34;
            this.txtPrice.Text = "8800";
            // 
            // txtQTY
            // 
            this.txtQTY.Location = new System.Drawing.Point(488, 41);
            this.txtQTY.Margin = new System.Windows.Forms.Padding(4);
            this.txtQTY.Name = "txtQTY";
            this.txtQTY.Size = new System.Drawing.Size(28, 25);
            this.txtQTY.TabIndex = 35;
            this.txtQTY.Text = "1";
            // 
            // cmbEffType
            // 
            this.cmbEffType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEffType.FormattingEnabled = true;
            this.cmbEffType.Items.AddRange(new object[] {
            "R",
            "F",
            "I"});
            this.cmbEffType.Location = new System.Drawing.Point(536, 44);
            this.cmbEffType.Margin = new System.Windows.Forms.Padding(4);
            this.cmbEffType.Name = "cmbEffType";
            this.cmbEffType.Size = new System.Drawing.Size(65, 23);
            this.cmbEffType.TabIndex = 36;
            // 
            // cboOpenOffSetFlag
            // 
            this.cboOpenOffSetFlag.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboOpenOffSetFlag.FormattingEnabled = true;
            this.cboOpenOffSetFlag.Items.AddRange(new object[] {
            "",
            "0",
            "1",
            "2"});
            this.cboOpenOffSetFlag.Location = new System.Drawing.Point(611, 44);
            this.cboOpenOffSetFlag.Margin = new System.Windows.Forms.Padding(4);
            this.cboOpenOffSetFlag.Name = "cboOpenOffSetFlag";
            this.cboOpenOffSetFlag.Size = new System.Drawing.Size(65, 23);
            this.cboOpenOffSetFlag.TabIndex = 37;
            // 
            // cboML
            // 
            this.cboML.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboML.FormattingEnabled = true;
            this.cboML.Items.AddRange(new object[] {
            "L",
            "M",
            "P"});
            this.cboML.Location = new System.Drawing.Point(683, 44);
            this.cboML.Margin = new System.Windows.Forms.Padding(4);
            this.cboML.Name = "cboML";
            this.cboML.Size = new System.Drawing.Size(65, 23);
            this.cboML.TabIndex = 39;
            // 
            // txtOrderNO
            // 
            this.txtOrderNO.Location = new System.Drawing.Point(5, 46);
            this.txtOrderNO.Margin = new System.Windows.Forms.Padding(4);
            this.txtOrderNO.Name = "txtOrderNO";
            this.txtOrderNO.Size = new System.Drawing.Size(68, 25);
            this.txtOrderNO.TabIndex = 42;
            // 
            // grbOrder
            // 
            this.grbOrder.Controls.Add(this.btnGetWB);
            this.grbOrder.Controls.Add(this.txtProductIdW);
            this.grbOrder.Controls.Add(this.label26);
            this.grbOrder.Controls.Add(this.txtTime_e);
            this.grbOrder.Controls.Add(this.label24);
            this.grbOrder.Controls.Add(this.label25);
            this.grbOrder.Controls.Add(this.txtTime_s);
            this.grbOrder.Controls.Add(this.txtOrderNo_e);
            this.grbOrder.Controls.Add(this.label23);
            this.grbOrder.Controls.Add(this.label22);
            this.grbOrder.Controls.Add(this.txtOrderNo_s);
            this.grbOrder.Controls.Add(this.button12);
            this.grbOrder.Controls.Add(this.cmbActno);
            this.grbOrder.Controls.Add(this.button28);
            this.grbOrder.Controls.Add(this.button11);
            this.grbOrder.Controls.Add(this.label14);
            this.grbOrder.Controls.Add(this.button4);
            this.grbOrder.Controls.Add(this.button5);
            this.grbOrder.Controls.Add(this.txtOrderNO);
            this.grbOrder.Controls.Add(this.label12);
            this.grbOrder.Controls.Add(this.btnOrder);
            this.grbOrder.Controls.Add(this.cboML);
            this.grbOrder.Controls.Add(this.label11);
            this.grbOrder.Controls.Add(this.cboOpenOffSetFlag);
            this.grbOrder.Controls.Add(this.label10);
            this.grbOrder.Controls.Add(this.cmbEffType);
            this.grbOrder.Controls.Add(this.label9);
            this.grbOrder.Controls.Add(this.txtQTY);
            this.grbOrder.Controls.Add(this.txtPrice);
            this.grbOrder.Controls.Add(this.txtBS);
            this.grbOrder.Controls.Add(this.label8);
            this.grbOrder.Controls.Add(this.txtProductID);
            this.grbOrder.Controls.Add(this.label7);
            this.grbOrder.Controls.Add(this.label6);
            this.grbOrder.Controls.Add(this.label5);
            this.grbOrder.Location = new System.Drawing.Point(23, 25);
            this.grbOrder.Margin = new System.Windows.Forms.Padding(4);
            this.grbOrder.Name = "grbOrder";
            this.grbOrder.Padding = new System.Windows.Forms.Padding(4);
            this.grbOrder.Size = new System.Drawing.Size(896, 256);
            this.grbOrder.TabIndex = 44;
            this.grbOrder.TabStop = false;
            this.grbOrder.Text = "委託";
            // 
            // btnGetWB
            // 
            this.btnGetWB.Location = new System.Drawing.Point(315, 181);
            this.btnGetWB.Margin = new System.Windows.Forms.Padding(4);
            this.btnGetWB.Name = "btnGetWB";
            this.btnGetWB.Size = new System.Drawing.Size(151, 29);
            this.btnGetWB.TabIndex = 57;
            this.btnGetWB.Text = "查詢買進Working";
            this.btnGetWB.UseVisualStyleBackColor = true;
            this.btnGetWB.Click += new System.EventHandler(this.btnGetWB_Click);
            // 
            // txtProductIdW
            // 
            this.txtProductIdW.Location = new System.Drawing.Point(315, 146);
            this.txtProductIdW.Margin = new System.Windows.Forms.Padding(4);
            this.txtProductIdW.Name = "txtProductIdW";
            this.txtProductIdW.Size = new System.Drawing.Size(131, 25);
            this.txtProductIdW.TabIndex = 56;
            this.txtProductIdW.Text = "TXFL4";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(312, 124);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(147, 15);
            this.label26.TabIndex = 55;
            this.label26.Text = "查詢Working商品代碼";
            // 
            // txtTime_e
            // 
            this.txtTime_e.Location = new System.Drawing.Point(221, 158);
            this.txtTime_e.Margin = new System.Windows.Forms.Padding(4);
            this.txtTime_e.Name = "txtTime_e";
            this.txtTime_e.Size = new System.Drawing.Size(68, 25);
            this.txtTime_e.TabIndex = 54;
            this.txtTime_e.Text = "18:00:00";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(191, 159);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(15, 15);
            this.label24.TabIndex = 53;
            this.label24.Text = "~";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(35, 158);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(67, 15);
            this.label25.TabIndex = 52;
            this.label25.Text = "時間起迄";
            // 
            // txtTime_s
            // 
            this.txtTime_s.Location = new System.Drawing.Point(113, 155);
            this.txtTime_s.Margin = new System.Windows.Forms.Padding(4);
            this.txtTime_s.Name = "txtTime_s";
            this.txtTime_s.Size = new System.Drawing.Size(68, 25);
            this.txtTime_s.TabIndex = 51;
            this.txtTime_s.Text = "08:00:00";
            // 
            // txtOrderNo_e
            // 
            this.txtOrderNo_e.Location = new System.Drawing.Point(221, 122);
            this.txtOrderNo_e.Margin = new System.Windows.Forms.Padding(4);
            this.txtOrderNo_e.Name = "txtOrderNo_e";
            this.txtOrderNo_e.Size = new System.Drawing.Size(68, 25);
            this.txtOrderNo_e.TabIndex = 50;
            this.txtOrderNo_e.Text = "zzzzz";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(191, 124);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(15, 15);
            this.label23.TabIndex = 49;
            this.label23.Text = "~";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(11, 124);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(97, 15);
            this.label22.TabIndex = 48;
            this.label22.Text = "委託書號起迄";
            // 
            // txtOrderNo_s
            // 
            this.txtOrderNo_s.Location = new System.Drawing.Point(113, 120);
            this.txtOrderNo_s.Margin = new System.Windows.Forms.Padding(4);
            this.txtOrderNo_s.Name = "txtOrderNo_s";
            this.txtOrderNo_s.Size = new System.Drawing.Size(68, 25);
            this.txtOrderNo_s.TabIndex = 47;
            this.txtOrderNo_s.Text = "00000";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(155, 192);
            this.button12.Margin = new System.Windows.Forms.Padding(4);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(136, 29);
            this.button12.TabIndex = 46;
            this.button12.Text = "查詢成交回報";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click_1);
            // 
            // cmbActno
            // 
            this.cmbActno.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbActno.FormattingEnabled = true;
            this.cmbActno.Location = new System.Drawing.Point(84, 46);
            this.cmbActno.Margin = new System.Windows.Forms.Padding(4);
            this.cmbActno.Name = "cmbActno";
            this.cmbActno.Size = new System.Drawing.Size(128, 23);
            this.cmbActno.TabIndex = 44;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(19, 192);
            this.button11.Margin = new System.Windows.Forms.Padding(4);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(136, 29);
            this.button11.TabIndex = 45;
            this.button11.Text = "查詢委託回報";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click_1);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(16, 28);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(37, 15);
            this.label14.TabIndex = 30;
            this.label14.Text = "單號";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(675, 22);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 15);
            this.label12.TabIndex = 21;
            this.label12.Text = "市價/限價";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(612, 22);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 15);
            this.label11.TabIndex = 20;
            this.label11.Text = "新平倉";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(533, 21);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 15);
            this.label10.TabIndex = 15;
            this.label10.Text = "委託條件";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(487, 22);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 15);
            this.label9.TabIndex = 14;
            this.label9.Text = "口數";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(413, 22);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 15);
            this.label8.TabIndex = 12;
            this.label8.Text = "委託價格";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(353, 22);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 15);
            this.label7.TabIndex = 11;
            this.label7.Text = "買賣別";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(219, 22);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 15);
            this.label6.TabIndex = 6;
            this.label6.Text = "商品代碼";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(80, 28);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 15);
            this.label5.TabIndex = 0;
            this.label5.Text = "下單帳號";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(632, 15);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(68, 29);
            this.button2.TabIndex = 45;
            this.button2.Text = "Logout";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(4, 51);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1189, 769);
            this.tabControl1.TabIndex = 46;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.lstOption);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.lstFuture);
            this.tabPage1.Controls.Add(this.button6);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.lstRegItem);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.lstI080);
            this.tabPage1.Controls.Add(this.lstI020);
            this.tabPage1.Controls.Add(this.lstI082);
            this.tabPage1.Controls.Add(this.lstI022);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.button7);
            this.tabPage1.Controls.Add(this.txtRegProductId);
            this.tabPage1.Controls.Add(this.button8);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(1181, 740);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "行情";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(599, 22);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(52, 15);
            this.label19.TabIndex = 29;
            this.label19.Text = "選擇權";
            // 
            // lstOption
            // 
            this.lstOption.FormattingEnabled = true;
            this.lstOption.ItemHeight = 15;
            this.lstOption.Location = new System.Drawing.Point(601, 44);
            this.lstOption.Margin = new System.Windows.Forms.Padding(4);
            this.lstOption.Name = "lstOption";
            this.lstOption.Size = new System.Drawing.Size(384, 94);
            this.lstOption.TabIndex = 28;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(195, 22);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(37, 15);
            this.label18.TabIndex = 27;
            this.label18.Text = "期貨";
            // 
            // lstFuture
            // 
            this.lstFuture.FormattingEnabled = true;
            this.lstFuture.ItemHeight = 15;
            this.lstFuture.Location = new System.Drawing.Point(197, 44);
            this.lstFuture.Margin = new System.Windows.Forms.Padding(4);
            this.lstFuture.Name = "lstFuture";
            this.lstFuture.Size = new System.Drawing.Size(384, 94);
            this.lstFuture.TabIndex = 26;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(29, 61);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(125, 46);
            this.button6.TabIndex = 25;
            this.button6.Text = "取得商品檔";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(312, 182);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(121, 46);
            this.button3.TabIndex = 24;
            this.button3.Text = "取得註冊列表";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(453, 159);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(67, 15);
            this.label17.TabIndex = 23;
            this.label17.Text = "註冊列表";
            // 
            // lstRegItem
            // 
            this.lstRegItem.FormattingEnabled = true;
            this.lstRegItem.ItemHeight = 15;
            this.lstRegItem.Location = new System.Drawing.Point(456, 180);
            this.lstRegItem.Margin = new System.Windows.Forms.Padding(4);
            this.lstRegItem.Name = "lstRegItem";
            this.lstRegItem.Size = new System.Drawing.Size(384, 94);
            this.lstRegItem.TabIndex = 22;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(460, 455);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(67, 15);
            this.label16.TabIndex = 21;
            this.label16.Text = "盤中五檔";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(27, 455);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(82, 15);
            this.label15.TabIndex = 20;
            this.label15.Text = "盤中成交價";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(463, 319);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 15);
            this.label4.TabIndex = 19;
            this.label4.Text = "盤前虛擬五檔";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 319);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 15);
            this.label3.TabIndex = 18;
            this.label3.Text = "盤前虛擬成交價";
            // 
            // lstI080
            // 
            this.lstI080.FormattingEnabled = true;
            this.lstI080.ItemHeight = 15;
            this.lstI080.Location = new System.Drawing.Point(463, 476);
            this.lstI080.Margin = new System.Windows.Forms.Padding(4);
            this.lstI080.Name = "lstI080";
            this.lstI080.Size = new System.Drawing.Size(384, 94);
            this.lstI080.TabIndex = 17;
            // 
            // lstI020
            // 
            this.lstI020.FormattingEnabled = true;
            this.lstI020.ItemHeight = 15;
            this.lstI020.Location = new System.Drawing.Point(29, 476);
            this.lstI020.Margin = new System.Windows.Forms.Padding(4);
            this.lstI020.Name = "lstI020";
            this.lstI020.Size = new System.Drawing.Size(417, 94);
            this.lstI020.TabIndex = 16;
            // 
            // lstI082
            // 
            this.lstI082.FormattingEnabled = true;
            this.lstI082.ItemHeight = 15;
            this.lstI082.Location = new System.Drawing.Point(456, 340);
            this.lstI082.Margin = new System.Windows.Forms.Padding(4);
            this.lstI082.Name = "lstI082";
            this.lstI082.Size = new System.Drawing.Size(391, 94);
            this.lstI082.TabIndex = 15;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnGetWS);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.dgvMatchReply);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.dgvOrderReply);
            this.tabPage2.Controls.Add(this.grbOrder);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(1181, 740);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "下單";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnGetWS
            // 
            this.btnGetWS.Location = new System.Drawing.Point(337, 242);
            this.btnGetWS.Margin = new System.Windows.Forms.Padding(4);
            this.btnGetWS.Name = "btnGetWS";
            this.btnGetWS.Size = new System.Drawing.Size(151, 29);
            this.btnGetWS.TabIndex = 58;
            this.btnGetWS.Text = "查詢賣出Working";
            this.btnGetWS.UseVisualStyleBackColor = true;
            this.btnGetWS.Click += new System.EventHandler(this.btnGetWS_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(15, 498);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(67, 15);
            this.label20.TabIndex = 48;
            this.label20.Text = "成交回報";
            // 
            // dgvMatchReply
            // 
            this.dgvMatchReply.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMatchReply.Location = new System.Drawing.Point(16, 516);
            this.dgvMatchReply.Margin = new System.Windows.Forms.Padding(4);
            this.dgvMatchReply.Name = "dgvMatchReply";
            this.dgvMatchReply.RowTemplate.Height = 24;
            this.dgvMatchReply.Size = new System.Drawing.Size(1105, 204);
            this.dgvMatchReply.TabIndex = 47;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(15, 285);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 15);
            this.label13.TabIndex = 46;
            this.label13.Text = "委託回報";
            // 
            // dgvOrderReply
            // 
            this.dgvOrderReply.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrderReply.Location = new System.Drawing.Point(16, 304);
            this.dgvOrderReply.Margin = new System.Windows.Forms.Padding(4);
            this.dgvOrderReply.Name = "dgvOrderReply";
            this.dgvOrderReply.RowTemplate.Height = 24;
            this.dgvOrderReply.Size = new System.Drawing.Size(1105, 188);
            this.dgvOrderReply.TabIndex = 45;
            this.dgvOrderReply.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOrderReply_CellClick);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button13);
            this.tabPage3.Controls.Add(this.cmbQueryAccount);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.button10);
            this.tabPage3.Controls.Add(this.dgvPosition);
            this.tabPage3.Controls.Add(this.button9);
            this.tabPage3.Controls.Add(this.dgvMargin);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1181, 740);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "帳務";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // cmbQueryAccount
            // 
            this.cmbQueryAccount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbQueryAccount.FormattingEnabled = true;
            this.cmbQueryAccount.Location = new System.Drawing.Point(9, 25);
            this.cmbQueryAccount.Margin = new System.Windows.Forms.Padding(4);
            this.cmbQueryAccount.Name = "cmbQueryAccount";
            this.cmbQueryAccount.Size = new System.Drawing.Size(128, 23);
            this.cmbQueryAccount.TabIndex = 46;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(7, 6);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(67, 15);
            this.label21.TabIndex = 45;
            this.label21.Text = "查詢帳號";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(8, 295);
            this.button10.Margin = new System.Windows.Forms.Padding(4);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(145, 29);
            this.button10.TabIndex = 3;
            this.button10.Text = "即時部位查詢";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // dgvPosition
            // 
            this.dgvPosition.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPosition.Location = new System.Drawing.Point(7, 331);
            this.dgvPosition.Margin = new System.Windows.Forms.Padding(4);
            this.dgvPosition.Name = "dgvPosition";
            this.dgvPosition.RowTemplate.Height = 24;
            this.dgvPosition.Size = new System.Drawing.Size(1168, 188);
            this.dgvPosition.TabIndex = 2;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(8, 58);
            this.button9.Margin = new System.Windows.Forms.Padding(4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(145, 29);
            this.button9.TabIndex = 1;
            this.button9.Text = "權益數查詢";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // dgvMargin
            // 
            this.dgvMargin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMargin.Location = new System.Drawing.Point(7, 94);
            this.dgvMargin.Margin = new System.Windows.Forms.Padding(4);
            this.dgvMargin.Name = "dgvMargin";
            this.dgvMargin.RowTemplate.Height = 24;
            this.dgvMargin.Size = new System.Drawing.Size(1168, 188);
            this.dgvMargin.TabIndex = 0;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(1, 19);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(44, 15);
            this.label27.TabIndex = 47;
            this.label27.Text = "Server";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(168, 20);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(52, 15);
            this.label28.TabIndex = 48;
            this.label28.Text = "分公司";
            // 
            // txtCompany
            // 
            this.txtCompany.Location = new System.Drawing.Point(225, 15);
            this.txtCompany.Margin = new System.Windows.Forms.Padding(4);
            this.txtCompany.Name = "txtCompany";
            this.txtCompany.Size = new System.Drawing.Size(71, 25);
            this.txtCompany.TabIndex = 49;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(305, 18);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(86, 30);
            this.label29.TabIndex = 50;
            this.label29.Text = "使用者代號/\r\n交易帳號";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(163, 58);
            this.button13.Margin = new System.Windows.Forms.Padding(4);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(145, 29);
            this.button13.TabIndex = 47;
            this.button13.Text = "夜盤權益數查詢";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1203, 824);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.txtCompany);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.txtServerIP);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtUserID);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "API範例";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grbOrder.ResumeLayout(false);
            this.grbOrder.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatchReply)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderReply)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPosition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMargin)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.TextBox txtUserID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtServerIP;
        private System.Windows.Forms.TextBox txtProductID;
        private System.Windows.Forms.TextBox txtBS;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.TextBox txtQTY;
        private System.Windows.Forms.ComboBox cmbEffType;
        private System.Windows.Forms.ComboBox cboOpenOffSetFlag;
        private System.Windows.Forms.ComboBox cboML;
        private System.Windows.Forms.Button btnOrder;
        private System.Windows.Forms.TextBox txtOrderNO;
        private System.Windows.Forms.GroupBox grbOrder;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRegProductId;
        private System.Windows.Forms.ListBox lstI022;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox lstI080;
        private System.Windows.Forms.ListBox lstI020;
        private System.Windows.Forms.ListBox lstI082;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ListBox lstRegItem;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ListBox lstOption;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ListBox lstFuture;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.DataGridView dgvMargin;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.DataGridView dgvPosition;
        private System.Windows.Forms.DataGridView dgvOrderReply;
        private System.Windows.Forms.ComboBox cmbActno;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.DataGridView dgvMatchReply;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cmbQueryAccount;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.TextBox txtTime_e;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtTime_s;
        private System.Windows.Forms.TextBox txtOrderNo_e;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtOrderNo_s;
        private System.Windows.Forms.Button btnGetWB;
        private System.Windows.Forms.TextBox txtProductIdW;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button btnGetWS;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtCompany;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button button13;
    }
}

