using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace API_Test
{
    public partial class Form1 : Form
    { 
       DataTable _Margin = new DataTable();
       DataTable _Postion = new DataTable();
       DataTable mdt_MatchDetailReply;
       DataTable mdt_OrderReply;
       HNTradeAPI.DDSCTradeAPI ddscAPI;
       public delegate void displayPriceDelegate(string type, string price);
       delegate void AddDataListDelegate(string strType, string strData);
       private delegate void parseReplyDatadelegate(string TRADEDATE, string ORDERNO, string ORDERTIME, string BROKERID, string INVESTORACNO, string BS, string PRODUCTID, string ORDERPRICE, string ORDERQTY, string MATCHQTY, string NOMATCHQTY, string DELQTY, string ORDERSTATUS, string STATUSCODE, string NETWORKID, string PRODUCTKIND, string OPENOFFSETFLAG, string ORDERCONDITION, string ORDERTYPE, string SEQ, string DTRADE, string MDATE, string ORDERKIND);
       private delegate void parseMatchDatadelegate(string TRADEDATE, string ORDERNO, string MATCHTIME, string BROKERID, string INVESTORACNO, string BS, string PRODUCTID, string MATCHPRICE, string MATCHQTY, string BS1, string PRODUCTID1, string MATCHPRICE1, string BS2, string PRODUCTID2, string MATCHPRICE2, string NETWORKID, string PRODUCTKIND, string OPENOFFSETFLAG, string MATCHSEQ, string DTRADE, string MDATE, string ORDERKIND);
        public Form1()
        {
            InitializeComponent();

        }
        private void button1_Click(object sender, EventArgs e)
        {
            // login��|�إ߻Pgateway���s�u , �æ^�ǰӫ~��T
            ddscAPI.Login(txtCompany.Text,this.txtUserID.Text.Trim(), this.txtPassword.Text.Trim(), this.txtServerIP.Text.Trim());
            if (ddscAPI.loginStatusFlag)
            {
                //���o�b��
                cmbActno.Items.Clear();
                cmbActno.Items.AddRange(ddscAPI.Accounts);
                cmbActno.SelectedIndex = 0;
                cmbQueryAccount.Items.Clear();
                cmbQueryAccount.Items.AddRange(ddscAPI.Accounts);
                cmbQueryAccount.SelectedIndex = 0;
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            ddscAPI.Logout();
        }
        private void Form1_Load(object sender, EventArgs e)
        { 
            this.cmbEffType.SelectedIndex = 0;
            this.cboML.SelectedIndex = 0; 
            this.cboOpenOffSetFlag.SelectedIndex = 0;

            ddscAPI = new HNTradeAPI.DDSCTradeAPI();
            ddscAPI.LoginStatus += new HNTradeAPI.DDSCTradeAPI.loginStatusEventHandler(ddscAPI_loginStatus);
            ddscAPI.Error += new HNTradeAPI.DDSCTradeAPI.errorEventHandler(ddscAPI_Error);
            ddscAPI.MarketInfoData += new HNTradeAPI.DDSCTradeAPI.MarketInfoDataEventHandler(ddscAPI_MarketInfoData);
            ddscAPI.MarketInfoDataMatch += new HNTradeAPI.DDSCTradeAPI.MarketInfoDataMatchEventHandler(ddscAPI_MarketInfoDataMatch);
            ddscAPI.BMarketInfoData += new HNTradeAPI.DDSCTradeAPI.BMarketInfoDataEventHandler(ddscAPI_BMarketInfoData);
            ddscAPI.BMarketInfoDataMatch += new HNTradeAPI.DDSCTradeAPI.BMarketInfoDataMatchEventHandler(ddscAPI_BMarketInfoDataMatch);
            ddscAPI.FutureData += new HNTradeAPI.DDSCTradeAPI.futureDataEventHandler(ddscAPI_FutureData);
            ddscAPI.OptionData += new HNTradeAPI.DDSCTradeAPI.optionDataEventHandler(ddscAPI_OptionData);
            ddscAPI.MarginData += new HNTradeAPI.DDSCTradeAPI.marginDataEventHandler(ddscAPI_MarginData);
            ddscAPI.PositionData += new HNTradeAPI.DDSCTradeAPI.positionDataEventHandler(ddscAPI_PositionData);
            ddscAPI.OrderReplyData += new HNTradeAPI.DDSCTradeAPI.orderReplyDataEventHandler(r_orderReplyData);
            ddscAPI.MatchReplyData += new HNTradeAPI.DDSCTradeAPI.matchReplyDataEventHandler(ddscAPI_matchReplyData);
            ddscAPI.QueryMatchReplyData += new HNTradeAPI.DDSCTradeAPI.matchReplyDataEventHandler(ddscAPI_matchReplyData);
            ddscAPI.QueryOrderReplyData += new HNTradeAPI.DDSCTradeAPI.orderReplyDataEventHandler(r_orderReplyData);
            initializedData(); 
        }
        /// <summary>
        /// ��l�e�U�ΦXTable
        /// </summary>
        private void initializedData()
        {
            mdt_OrderReply = new DataTable("OrderReply");
            mdt_OrderReply.Columns.Add("TRADEDATE");
            mdt_OrderReply.Columns.Add("ORDERNO");
            mdt_OrderReply.Columns.Add("ORDERTIME");
            mdt_OrderReply.Columns.Add("BROKERID");
            mdt_OrderReply.Columns.Add("INVESTORACNO");
            mdt_OrderReply.Columns.Add("BS");
            mdt_OrderReply.Columns.Add("PRODUCTID");
            mdt_OrderReply.Columns.Add("ORDERPRICE");
            mdt_OrderReply.Columns.Add("ORDERQTY");
            mdt_OrderReply.Columns.Add("MATCHQTY");
            mdt_OrderReply.Columns.Add("NOMATCHQTY");
            mdt_OrderReply.Columns.Add("DELQTY");
            mdt_OrderReply.Columns.Add("ORDERSTATUS");
            mdt_OrderReply.Columns.Add("STATUSCODE");
            mdt_OrderReply.Columns.Add("NETWORKID");
            mdt_OrderReply.Columns.Add("PRODUCTKIND");
            mdt_OrderReply.Columns.Add("OPENOFFSETFLAG");
            mdt_OrderReply.Columns.Add("ORDERCONDITION");
            mdt_OrderReply.Columns.Add("ORDERTYPE");
            mdt_OrderReply.Columns.Add("SEQ");
            mdt_OrderReply.Columns.Add("DTRADE");
            mdt_OrderReply.Columns.Add("MDATE");
            mdt_OrderReply.Columns.Add("ORDERKIND"); 
            dgvOrderReply.DataSource = mdt_OrderReply;
            mdt_MatchDetailReply = new DataTable("MatchDetailReply");
            mdt_MatchDetailReply.Columns.Add("TRADEDATE");
            mdt_MatchDetailReply.Columns.Add("ORDERNO");
            mdt_MatchDetailReply.Columns.Add("MATCHTIME");
            mdt_MatchDetailReply.Columns.Add("BROKERID");
            mdt_MatchDetailReply.Columns.Add("INVESTORACNO");
            mdt_MatchDetailReply.Columns.Add("BS");
            mdt_MatchDetailReply.Columns.Add("PRODUCTID");
            mdt_MatchDetailReply.Columns.Add("MATCHPRICE");
            mdt_MatchDetailReply.Columns.Add("MATCHQTY");
            mdt_MatchDetailReply.Columns.Add("BS1");
            mdt_MatchDetailReply.Columns.Add("PRODUCTID1");
            mdt_MatchDetailReply.Columns.Add("MATCHPRICE1");
            mdt_MatchDetailReply.Columns.Add("BS2");
            mdt_MatchDetailReply.Columns.Add("PRODUCTID2");
            mdt_MatchDetailReply.Columns.Add("MATCHPRICE2");
            mdt_MatchDetailReply.Columns.Add("NETWORKID");
            mdt_MatchDetailReply.Columns.Add("PRODUCTKIND");
            mdt_MatchDetailReply.Columns.Add("OPENOFFSETFLAG");
            mdt_MatchDetailReply.Columns.Add("MATCHSEQ");
            mdt_MatchDetailReply.Columns.Add("DTRADE");
            mdt_MatchDetailReply.Columns.Add("MDATE");
            mdt_MatchDetailReply.Columns.Add("ORDERKIND");
            DataColumn[] dcPrimaryKey = { mdt_MatchDetailReply.Columns["orderNo"], mdt_MatchDetailReply.Columns["netWorkId"], mdt_MatchDetailReply.Columns["matchseq"], mdt_MatchDetailReply.Columns["investorAcno"], mdt_MatchDetailReply.Columns["BROKERID"] };
            mdt_MatchDetailReply.PrimaryKey = dcPrimaryKey;
            dgvMatchReply.DataSource = mdt_MatchDetailReply;

            _Margin.Columns.Add("BROKER_ID", typeof(string));
            _Margin.Columns.Add("INVESTORACNO", typeof(string));
            _Margin.Columns.Add("CUR", typeof(string));
            _Margin.Columns.Add("RATE", typeof(string));
            _Margin.Columns.Add("YES_AC_BALANCE", typeof(string));
            _Margin.Columns.Add("DEPOSIT_AMT", typeof(string));
            _Margin.Columns.Add("WITHDRAW_AMT", typeof(string));
            _Margin.Columns.Add("PROMPT_AMT", typeof(string));
            _Margin.Columns.Add("REALIZE_PREMIUM", typeof(string));
            _Margin.Columns.Add("COVER_INCOME", typeof(string));
            _Margin.Columns.Add("TODAY_REAL_FEE", typeof(string));
            _Margin.Columns.Add("TODAY_REAL_TAX", typeof(string));
            _Margin.Columns.Add("ACCOUNT_BALANCE", typeof(string));
            _Margin.Columns.Add("VAR_INCOME", typeof(string));
            _Margin.Columns.Add("SUB_VAR_INCOME", typeof(string));
            _Margin.Columns.Add("COVER_AMT", typeof(string));
            _Margin.Columns.Add("ACCOUNT_EQUITY", typeof(string));
            _Margin.Columns.Add("B_OPTION_VALUE", typeof(string));
            _Margin.Columns.Add("S_OPTION_VALUE", typeof(string));
            _Margin.Columns.Add("EQUITY", typeof(string));
            _Margin.Columns.Add("INITIAL_MARGIN", typeof(string));
            _Margin.Columns.Add("MAINTAIN_MARGIN", typeof(string));
            _Margin.Columns.Add("O_INITIAL_MARGIN", typeof(string));
            _Margin.Columns.Add("UNREALIZE_PREMIUM", typeof(string));
            _Margin.Columns.Add("HEAD85", typeof(string));
            _Margin.Columns.Add("ADDITION_MARGIN", typeof(string));
            _Margin.Columns.Add("ADD_MARGIN_RATE", typeof(string));
            _Margin.Columns.Add("USABLE_MARGIN", typeof(string));
            _Margin.Columns.Add("WARNING_AMOUNT", typeof(string));
            _Margin.Columns.Add("RISK_RATE", typeof(string));
            _Margin.Columns.Add("VAR_INCOME_OPTION", typeof(string));

            _Postion.Columns.Add("BROKER_ID", typeof(string));
            _Postion.Columns.Add("INVESTORACNO", typeof(string));
            _Postion.Columns.Add("PRODUCTID", typeof(string));
            _Postion.Columns.Add("PRODUCTDESC", typeof(string));
            _Postion.Columns.Add("BS", typeof(string));
            _Postion.Columns.Add("POSITION_QTY", typeof(string));
            _Postion.Columns.Add("POSITION_PRICE", typeof(string));
            _Postion.Columns.Add("YES_POSITION", typeof(string));
            _Postion.Columns.Add("NOW_QTY", typeof(string));
            _Postion.Columns.Add("MARKET_PRICE", typeof(string));
            _Postion.Columns.Add("CLOSE_PRICE", typeof(string));
            _Postion.Columns.Add("B_MATCH_PRICE", typeof(string));
            _Postion.Columns.Add("S_MATCH_PRICE", typeof(string));
            _Postion.Columns.Add("B_MATCH_QTY", typeof(string));
            _Postion.Columns.Add("S_MATCH_QTY", typeof(string));
            _Postion.Columns.Add("FLOAT_PROFIT", typeof(string));
            _Postion.Columns.Add("U_FLOAT_PROFIT", typeof(string));
            _Postion.Columns.Add("INCOME_BALANCE", typeof(string));
            _Postion.Columns.Add("U_INCOME_BALANCE", typeof(string));
            _Postion.Columns.Add("COMTYPE", typeof(int));
            _Postion.Columns.Add("KIND_ID", typeof(string));
            _Postion.Columns.Add("STRIKE_PRICE", typeof(decimal));
            _Postion.Columns.Add("CP", typeof(string));
            _Postion.Columns.Add("MONTH", typeof(int));
            _Postion.Columns.Add("YEAR", typeof(int));
        } 
        void ddscAPI_PositionData(string Company, string Actno, string PRODUCTID, string PRODUCTDESC, string BS, string POSITION_QTY, string POSITION_PRICE, string YES_POSITION, string NOW_QTY, string MARKET_PRICE, string CLOSE_PRICE, string B_MATCH_PRICE, string S_MATCH_PRICE, string B_MATCH_QTY, string S_MATCH_QTY, string FLOAT_PROFIT, string U_FLOAT_PROFIT, string INCOME_BALANCE, string U_INCOME_BALANCE, string COMTYPE, string KIND_ID, string STRIKE_PRICE, string CP, string MONTH, string YEAR)
        {
            _Postion.Rows.Add(new object[] { Company, Actno, PRODUCTID, PRODUCTDESC, BS, POSITION_QTY, POSITION_PRICE, YES_POSITION, NOW_QTY, MARKET_PRICE, CLOSE_PRICE, B_MATCH_PRICE, S_MATCH_PRICE, B_MATCH_QTY, S_MATCH_QTY, FLOAT_PROFIT, U_FLOAT_PROFIT, INCOME_BALANCE, U_INCOME_BALANCE, COMTYPE, KIND_ID, STRIKE_PRICE, CP, MONTH, YEAR });
        }
        void ddscAPI_MarginData(string Company, string Actno, string CUR, string RATE, string YES_AC_BALANCE, string DEPOSIT_AMT, string WITHDRAW_AMT, string PROMPT_AMT, string REALIZE_PREMIUM, string COVER_INCOME, string TODAY_REAL_FEE, string TODAY_REAL_TAX, string ACCOUNT_BALANCE, string VAR_INCOME, string SUB_VAR_INCOME, string COVER_AMT, string ACCOUNT_EQUITY, string B_OPTION_VALUE, string S_OPTION_VALUE, string EQUITY, string INITIAL_MARGIN, string MAINTAIN_MARGIN, string O_INITIAL_MARGIN, string UNREALIZE_PREMIUM, string HEAD85, string ADDITION_MARGIN, string ADD_MARGIN_RATE, string USABLE_MARGIN, string WARNING_AMOUNT, string RISK_RATE, string VAR_INCOME_OPTION)
        {
            _Margin.Rows.Add(new object[] { Company, Actno, CUR, RATE, YES_AC_BALANCE, DEPOSIT_AMT, WITHDRAW_AMT, PROMPT_AMT, REALIZE_PREMIUM, COVER_INCOME, TODAY_REAL_FEE, TODAY_REAL_TAX, ACCOUNT_BALANCE, VAR_INCOME, SUB_VAR_INCOME, COVER_AMT, ACCOUNT_EQUITY, B_OPTION_VALUE, S_OPTION_VALUE, EQUITY, INITIAL_MARGIN, MAINTAIN_MARGIN, O_INITIAL_MARGIN, UNREALIZE_PREMIUM, HEAD85, ADDITION_MARGIN, ADD_MARGIN_RATE, USABLE_MARGIN, WARNING_AMOUNT, RISK_RATE, VAR_INCOME_OPTION });
        }
        void ddscAPI_OptionData(string Class, string PRODUCTID, string desc, string month, string cp, string strikePrice, string MaxPrice, string MinPrice, string ClosePrice)
        {
            string data = "Class:" + Class + " PRODUCTID:" + PRODUCTID + " desc:" + desc + " month:" + month + " cp:" + cp + " strikePrice:" + strikePrice + " MaxPrice:" + MaxPrice + " MinPrice:" + MinPrice + " ClosePrice:" + ClosePrice;
            this.Invoke(new displayPriceDelegate(displayMsg), new object[] { "O", data });
        }
        void ddscAPI_FutureData(string Class, string PRODUCTID, string desc, string month, string MaxPrice, string MinPrice, string ClosePrice)
        {
            string data = "Class:" + Class + " PRODUCTID:" + PRODUCTID + " desc:" + desc + " month:" + month + " ClosePrice:" + ClosePrice;
            this.Invoke(new displayPriceDelegate(displayMsg), new object[] { "F", data });
        }
        void displayMsg(string type, string msg)
        {
            ListBox lst = new ListBox();
            if (type == "O")
                lst = lstOption;
            else if (type == "F")
                lst = lstFuture;
            lst.Items.Add(msg);
        }
        void displayPrice(string type,string price)
        {
            ListBox lst=new ListBox();
            if (type == "I022")
                lst = lstI022;
            else if (type == "I082")
                lst = lstI082;
            else if (type == "I020")
                lst = lstI020;
            else if (type == "I080")
                lst = lstI080;
            if (lst.Items.Count > 5)
                lst.Items.Clear();
            lst.Items.Add(price);
        }
        void ddscAPI_BMarketInfoData(string PRODUCTID, string BP1, string BP2, string BP3, string BP4, string BP5, string BQ1, string BQ2, string BQ3, string BQ4, string BQ5, string SP1, string SP2, string SP3, string SP4, string SP5, string SQ1, string SQ2, string SQ3, string SQ4, string SQ5)
        {
            this.Invoke(new displayPriceDelegate(displayPrice), new object[] { "I082", "BP1:" + BP1 + " BQ1:" + BQ1 + " SP1:" + SP1 + " SQ1:" +SQ1 }); 
        }
        void ddscAPI_MarketInfoData(string PRODUCTID, string BP1, string BP2, string BP3, string BP4, string BP5, string BQ1, string BQ2, string BQ3, string BQ4, string BQ5, string SP1, string SP2, string SP3, string SP4, string SP5, string SQ1, string SQ2, string SQ3, string SQ4, string SQ5)
        {
            this.Invoke(new displayPriceDelegate(displayPrice), new object[] { "I080", "BP1:" + BP1 + " BQ1:" + BQ1 + " SP1:" + SP1 + " SQ1:" + SQ1 }); 
        }
        void ddscAPI_Error(string msg)
        {
            MessageBox.Show(msg);
        }
        void ddscAPI_loginStatus(string msg)
        {
            MessageBox.Show(msg);
        }
        void ddscAPI_BMarketInfoDataMatch(string PRODUCTID, string MatchTime, string MatchPrice, string MatchBuyCnt, string MatchSellCnt, string MatchQuantity, string MatchTotalQty)
        {
            this.Invoke(new displayPriceDelegate(displayPrice), new object[] { "I022", "MatchPrice:" + MatchPrice + " MatchQuantity:" + MatchQuantity }); 
        }
        void ddscAPI_MarketInfoDataMatch(string PRODUCTID, string MatchTime, string MatchPrice, string MatchBuyCnt, string MatchSellCnt, string MatchQuantity, string MatchTotalQty)
        {
            this.Invoke(new displayPriceDelegate(displayPrice), new object[] { "I020", "MatchPrice:" + MatchPrice + " MatchQuantity:" + MatchQuantity }); 
        }
        private void button7_Click(object sender, EventArgs e)
        {
            ddscAPI.RegItem(txtRegProductId.Text);
        }
        private void button8_Click(object sender, EventArgs e)
        {
            ddscAPI.UnRegItem(txtRegProductId.Text);
        }
        private void button3_Click_1(object sender, EventArgs e)
        {
            lstRegItem.Items.Clear();
            if (ddscAPI.QueryRegItemList() != null)
            {
                foreach (string str in ddscAPI.QueryRegItemList())
                {
                    lstRegItem.Items.Add(str);
                }
            }
        }
        private void btnOrder_Click(object sender, EventArgs e)
        {
            ddscAPI.NewOrder(cmbActno.Text, txtProductID.Text, txtBS.Text, txtPrice.Text, txtQTY.Text, cboML.Text, cmbEffType.Text, cboOpenOffSetFlag.Text);
        }
        private void button4_Click(object sender, EventArgs e)
        { 
            ddscAPI.CancelOrder(cmbActno.Text, txtOrderNO.Text); 
        }
        private void button5_Click(object sender, EventArgs e)
        { 
            ddscAPI.DeleteQtyOrder(cmbActno.Text, txtOrderNO.Text, txtQTY.Text); 
        } 
        private void button28_Click(object sender, EventArgs e)
        {
             ddscAPI.ChangePriceOrder(cmbActno.Text, txtOrderNO.Text, txtPrice.Text, cboML.Text, cmbEffType.Text);
        }
     
        private void button6_Click(object sender, EventArgs e)
        {
            lstFuture.Items.Clear();
            lstOption.Items.Clear();
            ddscAPI.GetProductData();
        }
        private void button9_Click(object sender, EventArgs e)
        {
            _Margin.Rows.Clear();
            ddscAPI.GetMargin(cmbQueryAccount.Text );
            dgvMargin.DataSource = _Margin;
        }
        private void button10_Click(object sender, EventArgs e)
        {
            _Postion.Rows.Clear();
            ddscAPI.GetPosition(cmbQueryAccount.Text);
            dgvPosition.DataSource = _Postion;

        }
        private void refreshOrderReply(string TRADEDATE, string ORDERNO, string ORDERTIME, string BROKERID, string INVESTORACNO, string BS, string PRODUCTID, string ORDERPRICE, string ORDERQTY, string MATCHQTY, string NOMATCHQTY, string DELQTY, string ORDERSTATUS, string STATUSCODE, string NETWORKID, string PRODUCTKIND, string OPENOFFSETFLAG, string ORDERCONDITION, string ORDERTYPE, string SEQ, string DTRADE, string MDATE,string ORDERKIND)
        {
            string strcmd = "networkId ='" + NETWORKID + "' and orderno='" + ORDERNO + "' ";
            DataRow[] drGetDatas = mdt_OrderReply.Select(strcmd);

            if (drGetDatas.Length > 0)
            {
                drGetDatas[0].BeginEdit();
                drGetDatas[0]["TRADEDATE"] = TRADEDATE;
                drGetDatas[0]["ORDERNO"] = ORDERNO;
                drGetDatas[0]["ORDERTIME"] = ORDERTIME;
                drGetDatas[0]["BROKERID"] = BROKERID;
                drGetDatas[0]["INVESTORACNO"] = INVESTORACNO;
                drGetDatas[0]["BS"] = BS;
                drGetDatas[0]["PRODUCTID"] = PRODUCTID;
                drGetDatas[0]["ORDERPRICE"] = ORDERPRICE;
                drGetDatas[0]["ORDERQTY"] = ORDERQTY;
                drGetDatas[0]["MATCHQTY"] = MATCHQTY;
                drGetDatas[0]["NOMATCHQTY"] = NOMATCHQTY;
                drGetDatas[0]["DELQTY"] = DELQTY;
                drGetDatas[0]["ORDERSTATUS"] = ORDERSTATUS;
                drGetDatas[0]["STATUSCODE"] = STATUSCODE;
                drGetDatas[0]["NETWORKID"] = NETWORKID;
                drGetDatas[0]["PRODUCTKIND"] = PRODUCTKIND;
                drGetDatas[0]["OPENOFFSETFLAG"] = OPENOFFSETFLAG;
                drGetDatas[0]["ORDERCONDITION"] = ORDERCONDITION;
                drGetDatas[0]["ORDERTYPE"] = ORDERTYPE;
                drGetDatas[0]["SEQ"] = SEQ;
                drGetDatas[0]["DTRADE"] = DTRADE;
                drGetDatas[0]["MDATE"] = MDATE;
                drGetDatas[0]["ORDERKIND"] = ORDERKIND;
                drGetDatas[0].EndEdit();
            }
            else
            {
                DataRow drAddRow = mdt_OrderReply.NewRow();
                drAddRow["TRADEDATE"] = TRADEDATE;
                drAddRow["ORDERNO"] = ORDERNO;
                drAddRow["ORDERTIME"] = ORDERTIME;
                drAddRow["BROKERID"] = BROKERID;
                drAddRow["INVESTORACNO"] = INVESTORACNO;
                drAddRow["BS"] = BS;
                drAddRow["PRODUCTID"] = PRODUCTID;
                drAddRow["ORDERPRICE"] = ORDERPRICE;
                drAddRow["ORDERQTY"] = ORDERQTY;
                drAddRow["MATCHQTY"] = MATCHQTY;
                drAddRow["NOMATCHQTY"] = NOMATCHQTY;
                drAddRow["DELQTY"] = DELQTY;
                drAddRow["ORDERSTATUS"] = ORDERSTATUS;
                drAddRow["STATUSCODE"] = STATUSCODE;
                drAddRow["NETWORKID"] = NETWORKID;
                drAddRow["PRODUCTKIND"] = PRODUCTKIND;
                drAddRow["OPENOFFSETFLAG"] = OPENOFFSETFLAG;
                drAddRow["ORDERCONDITION"] = ORDERCONDITION;
                drAddRow["ORDERTYPE"] = ORDERTYPE;
                drAddRow["SEQ"] = SEQ;
                drAddRow["DTRADE"] = DTRADE;
                drAddRow["MDATE"] = MDATE;
                drAddRow["ORDERKIND"] = ORDERKIND;
                mdt_OrderReply.Rows.Add(drAddRow);
            }

        }
        void r_orderReplyData(string TRADEDATE, string ORDERNO, string ORDERTIME, string BROKERID, string INVESTORACNO, string BS, string PRODUCTID, string ORDERPRICE, string ORDERQTY, string MATCHQTY, string NOMATCHQTY, string DELQTY, string ORDERSTATUS, string STATUSCODE, string NETWORKID, string PRODUCTKIND, string OPENOFFSETFLAG, string ORDERCONDITION, string ORDERTYPE, string SEQ, string DTRADE, string MDATE,string ORDERKIND)
        {
            this.dgvOrderReply.BeginInvoke(new parseReplyDatadelegate(refreshOrderReply), new Object[] { TRADEDATE,ORDERNO,ORDERTIME,BROKERID,INVESTORACNO,BS,PRODUCTID,ORDERPRICE,ORDERQTY,MATCHQTY,NOMATCHQTY,DELQTY,ORDERSTATUS,STATUSCODE,NETWORKID,PRODUCTKIND,OPENOFFSETFLAG,ORDERCONDITION,ORDERTYPE,SEQ,DTRADE,MDATE,ORDERKIND });
        }
        private void dgvOrderReply_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex > -1 && e.RowIndex > -1)
            {
                txtOrderNO.Text = mdt_OrderReply.Rows[e.RowIndex]["orderno"].ToString();
            }
        }
        void ddscAPI_matchReplyData(string TRADEDATE, string ORDERNO, string MATCHTIME, string BROKERID, string INVESTORACNO, string BS, string PRODUCTID, string MATCHPRICE, string MATCHQTY, string BS1, string PRODUCTID1, string MATCHPRICE1, string BS2, string PRODUCTID2, string MATCHPRICE2, string NETWORKID, string PRODUCTKIND, string OPENOFFSETFLAG, string MATCHSEQ, string DTRADE, string MDATE, string ORDERKIND)
        {
            this.dgvMatchReply.BeginInvoke(new parseMatchDatadelegate(refreshMatchReply), new Object[] {  TRADEDATE,ORDERNO,MATCHTIME,BROKERID,INVESTORACNO,BS,PRODUCTID,MATCHPRICE,MATCHQTY,BS1,PRODUCTID1,MATCHPRICE1,BS2,PRODUCTID2,MATCHPRICE2,NETWORKID,PRODUCTKIND,OPENOFFSETFLAG,MATCHSEQ,DTRADE,MDATE ,ORDERKIND});
        }
        private void refreshMatchReply(string TRADEDATE, string ORDERNO, string MATCHTIME, string BROKERID, string INVESTORACNO, string BS, string PRODUCTID, string MATCHPRICE, string MATCHQTY, string BS1, string PRODUCTID1, string MATCHPRICE1, string BS2, string PRODUCTID2, string MATCHPRICE2, string NETWORKID, string PRODUCTKIND, string OPENOFFSETFLAG, string MATCHSEQ, string DTRADE, string MDATE, string ORDERKIND)
        {
            DataRow drFind = mdt_MatchDetailReply.Rows.Find(new object[] { ORDERNO, NETWORKID, MATCHSEQ, INVESTORACNO, BROKERID });
            if (drFind == null)
            {
                DataRow drAddRow = mdt_MatchDetailReply.NewRow();
                drAddRow["TRADEDATE"] = TRADEDATE;
                drAddRow["ORDERNO"] = ORDERNO;
                drAddRow["MATCHTIME"] = MATCHTIME;
                drAddRow["BROKERID"] = BROKERID;
                drAddRow["INVESTORACNO"] = INVESTORACNO;
                drAddRow["BS"] = BS;
                drAddRow["PRODUCTID"] = PRODUCTID;
                drAddRow["MATCHPRICE"] = MATCHPRICE;
                drAddRow["MATCHQTY"] = MATCHQTY;
                drAddRow["BS1"] = BS1;
                drAddRow["PRODUCTID1"] = PRODUCTID1;
                drAddRow["MATCHPRICE1"] = MATCHPRICE1;
                drAddRow["BS2"] = BS2;
                drAddRow["PRODUCTID2"] = PRODUCTID2;
                drAddRow["MATCHPRICE2"] = MATCHPRICE2;
                drAddRow["NETWORKID"] = NETWORKID;
                drAddRow["PRODUCTKIND"] = PRODUCTKIND;
                drAddRow["OPENOFFSETFLAG"] = OPENOFFSETFLAG;
                drAddRow["MATCHSEQ"] = MATCHSEQ;
                drAddRow["DTRADE"] = DTRADE;
                drAddRow["MDATE"] = MDATE;
                drAddRow["ORDERKIND"] = ORDERKIND;
                mdt_MatchDetailReply.Rows.Add(drAddRow);
            }
        }
        private void button11_Click_1(object sender, EventArgs e)
        {
            mdt_OrderReply.Rows.Clear();
            ddscAPI.GetOrderReply(cmbActno.Text, txtOrderNo_s.Text, txtOrderNo_e.Text,txtTime_s.Text ,txtTime_e.Text );
        }
        private void button12_Click_1(object sender, EventArgs e)
        {
            mdt_MatchDetailReply.Rows.Clear();
            ddscAPI.GetMatchReply(cmbActno.Text, txtOrderNo_s.Text, txtOrderNo_e.Text, txtTime_s.Text, txtTime_e.Text);
        }
        private void btnGetWB_Click(object sender, EventArgs e)
        {
            MessageBox.Show("�ثe�R�iWorking��"+ddscAPI.GetWB(cmbActno.Text, txtProductIdW.Text).ToString() + "�f");
        }
        private void btnGetWS_Click(object sender, EventArgs e)
        {
            MessageBox.Show("�ثe��XWorking��" + ddscAPI.GetWS(cmbActno.Text, txtProductIdW.Text).ToString() + "�f");
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            _Margin.Rows.Clear();
            ddscAPI.GetNightMargin(cmbQueryAccount.Text );
            dgvMargin.DataSource = _Margin;
        }

     
    
    }
}